package ACT;
// DAO: Database Access Object
// �M�d�PDept Table���s�W,�ק�,�R���P�d��

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import ACT.ActBean;

public class ActDAO1 {

  private static Connection conn;

  public ActDAO1(Connection conn) {
		ActDAO1.conn = conn;
  }

  public static Connection getConnection(){  

		Connection conn=null;  
		    try {		
		    	
		    String url="jdbc:sqlserver://localhost:1433;databaseName=BookDB";
		    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    conn=DriverManager.getConnection(url, "scott", "tiger");
		    
			System.out.println(0);
			
		    }catch(Exception e){System.out.println(e);}  
		    return conn;  
		}  
  
  public static int save(ActBean act){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement(  
	"insert into ACT_MBrecord(MB_ID,ACT_Name,ACT_Theme,ACT_Date,ACT_Loc,ACT_Intro,ACT_Guest,ACT_Pax,ACT_Rule,ACT_Tag,ACT_Place) values(?,?,?,?,?,?,?,?,?,?,?)");  
	        ps.setInt(1,act.getMB_ID());  
	        ps.setString(2,act.getACT_Name());  
	        ps.setString(3,act.getACT_Theme());  
	        ps.setString(4,act.getACT_Date());  
	        ps.setString(5,act.getACT_Loc());
	        ps.setString(6,act.getACT_Intro());
	        ps.setString(7,act.getACT_Guest());
	        ps.setString(8,act.getACT_Pax());
	        ps.setString(9,act.getACT_Rule());
	        ps.setString(10,act.getACT_Tag());
	        ps.setString(11,act.getACT_Place());
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
  
  public static int update(ActBean act){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement(  
	"update ACT_MBrecord set ACT_Name=?,ACT_Theme=?,ACT_Date=?,ACT_Loc=?,ACT_Intro=?,ACT_Guest=?,ACT_Pax=?,ACT_Rule=?,ACT_Tag=?,ACT_Place=? where MB_ID=?");  

	        ps.setString(1,act.getACT_Name());  
	        ps.setString(2,act.getACT_Theme());  
	        ps.setString(3,act.getACT_Date());  
	        ps.setString(4,act.getACT_Loc());
	        ps.setString(5,act.getACT_Intro());
	        ps.setString(6,act.getACT_Guest());
	        ps.setString(7,act.getACT_Pax());
	        ps.setString(8,act.getACT_Rule());
	        ps.setString(9,act.getACT_Tag());
	        ps.setString(10,act.getACT_Place());
	        ps.setInt(11,act.getMB_ID()); 
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
  
  public static int delete(ActBean act){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("delete from register where MB_ID=? and ACT_Name=? ");  
	        ps.setInt(1,act.getMB_ID());  
	        ps.setString(2,act.getACT_Name());
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	  
	    return status;  
	}  
  
  public static List<ActBean> getAllRecords(){  
	    List<ActBean> list=new ArrayList<ActBean>();  
	      
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from ACT_MBrecord");  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            ActBean act=new ActBean();  
	            act.setACT_Name(rs.getString("ACT_Name"));
	        	act.setACT_Theme(rs.getString("ACT_Theme"));
	        	act.setACT_Date(rs.getString("ACT_Date"));
	        	act.setACT_Loc(rs.getString("ACT_Loc"));
	        	act.setACT_Intro(rs.getString("ACT_Intro"));
	        	act.setACT_Guest(rs.getString("ACT_Guest"));
	        	act.setACT_Pax(rs.getString("ACT_Pax"));
	        	act.setACT_Rule(rs.getString("ACT_Rule"));
	        	act.setACT_Tag(rs.getString("ACT_Tag"));
	        	act.setACT_Place(rs.getString("ACT_Place"));  
	            list.add(act);  
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return list;  
	}  
	public static ActBean getRecordById(int MB_ID){  
	    ActBean act=null;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from ACT_MBrecord where MB_ID=?");  
	        ps.setInt(1,MB_ID);  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            act=new ActBean();
	            act.setMB_ID(rs.getInt("MB_ID"));
	            act.setACT_Name(rs.getString("ACT_Name"));
	        	act.setACT_Theme(rs.getString("ACT_Theme"));
	        	act.setACT_Date(rs.getString("ACT_Date"));
	        	act.setACT_Loc(rs.getString("ACT_Loc"));
	        	act.setACT_Intro(rs.getString("ACT_Intro"));
	        	act.setACT_Guest(rs.getString("ACT_Guest"));
	        	act.setACT_Pax(rs.getString("ACT_Pax"));
	        	act.setACT_Rule(rs.getString("ACT_Rule"));
	        	act.setACT_Tag(rs.getString("ACT_Tag"));
	        	act.setACT_Place(rs.getString("ACT_Place")); 
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return act;  
	}  
  
}
