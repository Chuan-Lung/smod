package ACT;

import javax.servlet.*;
//import javax.servlet.http.*;
//import java.io.PrintWriter;
//import java.io.IOException;
import mvcdemo.bean.*;
import java.io.*;

import java.sql.*;
//import javax.rmi.*;
import javax.naming.*;
import javax.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 private static final String CONTENT_TYPE = "text/html; charset=UTF-8";
	 private static final String CHARSET_CODE = "UTF-8";
	 public void init(ServletConfig config) throws ServletException
	 {
	   super.init(config);
	 }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    request.setCharacterEncoding(CHARSET_CODE);
	    response.setContentType(CONTENT_TYPE);

	    // To prevent caching 
	   response.setHeader("Cache-Control","no-cache"); // HTTP 1.1
	   response.setHeader("Pragma","no-cache"); // HTTP 1.0
	   response.setDateHeader ("Expires", -1); // Prevents caching at the proxy server

	    
	   if (request.getParameter("submit")!=null)
	     gotoSubmitProcess(request, response);
	   else if (request.getParameter("confirm")!=null)
	     gotoConfirmProcess(request, response);
	}
	
	 public void gotoSubmitProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	  {
		  String ACT_ID;
		  String ACT_Name; 
		  String ACT_Theme;
		  String ACT_Date;
		  String ACT_Loc;
		  String ACT_Intro;
		  String ACT_Guest;
		  String ACT_Pax;
		  String ACT_Rule;
		  String ACT_Tag;
		  String ACT_Place;
	   
	    ACT_ID = request.getParameter("ACT_ID").trim();
	    ACT_Name = request.getParameter("ACT_Name").trim();
	    ACT_Theme = request.getParameter("ACT_Theme").trim();
	    ACT_Date = request.getParameter("ACT_Date").trim();
	    ACT_Loc = request.getParameter("ACT_Loc").trim();
	    ACT_Intro = request.getParameter("ACT_Intro").trim();
	    ACT_Guest = request.getParameter("ACT_Guest").trim();
	    ACT_Pax = request.getParameter("ACT_Pax").trim();
	    ACT_Rule = request.getParameter("ACT_Rule").trim();
	    ACT_Tag = request.getParameter("ACT_Tag").trim();
	    ACT_Place = request.getParameter("ACT_Place").trim();
	    ActBean reg_act =  new ActBean(ACT_ID, ACT_Name, ACT_Theme, ACT_Date, ACT_Loc, ACT_Intro, ACT_Guest, ACT_Pax, ACT_Rule, ACT_Tag, ACT_Place);
	    request.getSession(true).setAttribute("reg_act",reg_act);
	    request.getRequestDispatcher("/DisplayAct.jsp").forward(request,response);
	  }

	  public void gotoConfirmProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	  {

	    DataSource ds = null;
	    InitialContext ctxt = null;
	    Connection conn = null;
	    
	    try {
	     
	      //�إ�Context Object,�s��JNDI Server
	      ctxt = new InitialContext();

	      //�ϥ�JNDI API���DataSource
	      ds = ( DataSource ) ctxt.lookup("java:comp/env/jdbc/EmployeeDB");
	     //ds = ( DataSource ) ctxt.lookup("jdbc/OracleXE");
	      //�VDataSource�nConnection
	      conn = ds.getConnection();

	      //�إ�Database Access Object,�t�dTable��Access
	      ActDAO actDAO = new ActDAO(conn);
	      ActBean actData = (ActBean)request.getSession(true).getAttribute("reg_act");
	      if (actDAO.insertAct(actData))
	        {
	          System.out.println("Get some SQL commands done!");
	          request.getSession(true).invalidate();
	          request.getRequestDispatcher("/Thanks.jsp").forward(request,response);
	        }
	    } catch (NamingException ne) {
	      System.out.println("Naming Service Lookup Exception");  
	    } catch (SQLException e) {
	      System.out.println("Database Connection Error"); 
	    } finally {
	      try {
	        if (conn != null) conn.close();
	      } catch (Exception e) {
	        System.out.println("Connection Pool Error!");
	      }
	    }
	           
	  }

}
