package ACT;
// DAO: Database Access Object
// �M�d�PDept Table���s�W,�ק�,�R���P�d��

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import ACT.ActBean;

public class ActDAO {

  private static Connection conn;

  public ActDAO(Connection conn) {
		ActDAO.conn = conn;
  }

  public static Connection getConnection(){  

		Connection conn=null;  
		    try {		
		    	
		    String url="jdbc:sqlserver://localhost:1433;databaseName=BookDB";
		    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    conn=DriverManager.getConnection(url, "scott", "tiger");
		    
			System.out.println(0);
			
		    }catch(Exception e){System.out.println(e);}  
		    return conn;  
		}  
	  


	  public ActDAO() {
	  } 
	  
	  
  public boolean insertAct(ActBean ActData) {
    try {
      String sqlString = "insert into ACT_MBrecord values('"
	                  	   	+ ActData.getMB_ID()+"','"
		                    + ActData.getACT_Name()+"','"
                            + ActData.getACT_Theme()+"','"
                            + ActData.getACT_Date()+"','"
                            + ActData.getACT_Loc()+"','" 
                            + ActData.getACT_Intro()+"','"
                            + ActData.getACT_Guest()+"','"
                            + ActData.getACT_Pax()+"','"
                            + ActData.getACT_Rule()+"','"
                            + ActData.getACT_Tag()+"','"
                            + ActData.getACT_Place()+ "')";
                           
      Statement stmt = conn.createStatement();
      System.out.println(sqlString);
	    int updatecount = stmt.executeUpdate(sqlString);
      stmt.close();
      if (updatecount >= 1) return true;
      else                  return false;
	  } catch (Exception e) {
	    System.err.println("錯誤:" + e);
		  return false;
    }
  }

  public static List<ActBean> searchAct(String ACT_Name) {

		List<ActBean> list = new ArrayList<>();
		
	    try {
	    	Connection conn =getConnection(); 
	        Statement stmt = conn.createStatement();
	        ACT_Name = "'%" + ACT_Name + "%'";
	        String sqlString = "SELECT * FROM ACT_MBrecord WHERE ACT_Name like " + ACT_Name;
	        ResultSet rs = stmt.executeQuery(sqlString);
	        
	        while (rs.next()) {
	        	ActBean act = new ActBean();
	        	       
	        	act.setACT_Name(rs.getString("ACT_Name"));
	        	act.setACT_Theme(rs.getString("ACT_Theme"));
	        	act.setACT_Date(rs.getString("ACT_Date"));
	        	act.setACT_Loc(rs.getString("ACT_Loc"));
	        	act.setACT_Intro(rs.getString("ACT_Intro"));
	        	act.setACT_Guest(rs.getString("ACT_Guest"));
	        	act.setACT_Pax(rs.getString("ACT_Pax"));
	        	act.setACT_Rule(rs.getString("ACT_Rule"));
	        	act.setACT_Tag(rs.getString("ACT_Tag"));
	        	act.setACT_Place(rs.getString("ACT_Place"));
	        	list.add(act);
	        }
	  	  rs.close();
	  	  stmt.close();
	    	

		  } catch (Exception e) {
		    System.err.println("錯誤" + e);
	    }
	    return list;
		
	  }
  
  
  public static int delete(int MB_ID, String ACT_Name){  
	    int status=0;
	    try{  
	    	Connection conn =getConnection();      
	        PreparedStatement ps=conn.prepareStatement("DELETE FROM ACT_MBrecord WHERE MB_ID = ? and ACT_Name = ?;");  
	        ps.setInt(1,MB_ID);
	        ps.setString(2,ACT_Name);

	        status=ps.executeUpdate();  
	        
	    }catch(Exception e){System.out.println(e);}  
	  
	    return status;  
	}  
  
}